import java.util.*;
import java.util.regex.*;

class LexicalException extends Exception {
    public LexicalException(String message) {
        super(message);
    }
}

class Task2Exception extends Exception {
    public Task2Exception(String message) {
        super(message);
    }
}

interface Token {}

class T_Integer implements Token {
    public int n;
    public T_Integer(int _n) {
        n = _n;
    }
}

class T_Identifier implements Token {
    public String name;
    public T_Identifier(String _name) {
        name = _name;
    }
}

class T_Def implements Token {}
class T_If implements Token {}
class T_Then implements Token {}
class T_Else implements Token {}
class T_LeftCurlyBracket implements Token {}
class T_RightCurlyBracket implements Token {}
class T_Equal implements Token {}
class T_Semicolon implements Token {}

interface Lexer {
    public List<Token> lex(String input) throws LexicalException, Task2Exception;
}

class Task2 {
    private static final Pattern pattern = Pattern.compile(
        "\\s*(?<def>def)|(?<int>\\d+)|(?<id>[a-zA-Z_][a-zA-Z0-9_]*)|(?<if>if)|(?<then>then)|(?<else>else)|" +
        "(?<lbrace>\\{)|(?<rbrace>\\})|(?<eq>=)|(?<semicolon>;)|(?<error>\\S+)"
    );

    public static Lexer create() {
        return new Lexer() {
            @Override
            public List<Token> lex(String input) throws LexicalException, Task2Exception {
                if (input == null || input.isEmpty()) {
                    throw new Task2Exception("Input string cannot be null or empty.");
                }

                List<Token> tokens = new ArrayList<>();
                Matcher matcher = pattern.matcher(input);

                while (matcher.find()) {
                    if (matcher.group("def") != null) {
                        tokens.add(new T_Def());
                    } else if (matcher.group("int") != null) {
                        tokens.add(new T_Integer(Integer.parseInt(matcher.group("int"))));
                    } else if (matcher.group("id") != null) {
                        tokens.add(new T_Identifier(matcher.group("id")));
                    } else if (matcher.group("if") != null) {
                        tokens.add(new T_If());
                    } else if (matcher.group("then") != null) {
                        tokens.add(new T_Then());
                    } else if (matcher.group("else") != null) {
                        tokens.add(new T_Else());
                    } else if (matcher.group("lbrace") != null) {
                        tokens.add(new T_LeftCurlyBracket());
                    } else if (matcher.group("rbrace") != null) {
                        tokens.add(new T_RightCurlyBracket());
                    } else if (matcher.group("eq") != null) {
                        tokens.add(new T_Equal());
                    } else if (matcher.group("semicolon") != null) {
                        tokens.add(new T_Semicolon());
                    } else if (matcher.group("error") != null) {
                        throw new LexicalException("Invalid token: " + matcher.group("error"));
                    }
                }

                return tokens;
            }
        };
    }
}

class Main {
    public static void main(String[] args) throws Exception {
        Lexer lexer = Task2.create();

        // Test input string
        String input = "{ def x = 10 ; }";

        try {
            System.out.println("Input string: " + input);
            List<Token> tokens = lexer.lex(input);
            System.out.println("Tokens:");
            for (Token token : tokens) {
                if (token instanceof T_Integer) {
                    System.out.println("Integer: " + ((T_Integer) token).n);
                } else if (token instanceof T_Identifier) {
                    System.out.println("Identifier: " + ((T_Identifier) token).name);
                } else {
                    System.out.println(token.getClass().getSimpleName());
                }
            }
        } catch (LexicalException | Task2Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
