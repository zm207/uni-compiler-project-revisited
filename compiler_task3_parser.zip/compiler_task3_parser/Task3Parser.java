import java.util.*;

class SyntaxException extends Exception {
    public SyntaxException(String message) {
        super(message);
    }
}

class Task3Exception extends Exception {
    public Task3Exception(String message) {
        super(message);
    }
}

class Block {
    public List<Object> contents;

    public Block(List<Object> contents) {
        this.contents = contents;
    }
}

interface Token {}
class T_Integer implements Token {
    public int value;
    public T_Integer(int value) {
        this.value = value;
    }
}
class T_Skip implements Token {}
class T_LeftCurlyBracket implements Token {}
class T_RightCurlyBracket implements Token {}
class T_Semicolon implements Token {}

interface Parser {
    Block parse(List<Token> input) throws SyntaxException, Task3Exception;
}

class Task3 {
    public static Parser create() {
        return new Parser() {
            private List<Token> tokens;
            private int currentIndex;

            private Token currentToken() {
                if (currentIndex < tokens.size()) {
                    return tokens.get(currentIndex);
                }
                return null;
            }

            private void consume() {
                currentIndex++;
            }

            private void expect(Class<? extends Token> expected) throws SyntaxException {
                if (currentToken() == null || !expected.isInstance(currentToken())) {
                    throw new SyntaxException("Expected token: " + expected.getSimpleName());
                }
                consume();
            }

            @Override
            public Block parse(List<Token> input) throws SyntaxException, Task3Exception {
                this.tokens = input;
                this.currentIndex = 0;
                return parseBlock();
            }

            private Block parseBlock() throws SyntaxException {
                expect(T_LeftCurlyBracket.class);
                List<Object> contents = parseENE();
                expect(T_RightCurlyBracket.class);
                return new Block(contents);
            }

            private List<Object> parseENE() throws SyntaxException {
                List<Object> contents = new ArrayList<>();
                contents.add(parseE());
                while (currentToken() instanceof T_Semicolon) {
                    consume();
                    contents.add(parseE());
                }
                return contents;
            }

            private Object parseE() throws SyntaxException {
                if (currentToken() instanceof T_Integer) {
                    T_Integer integerToken = (T_Integer) currentToken();
                    consume();
                    return integerToken.value;
                } else if (currentToken() instanceof T_Skip) {
                    consume();
                    return "skip";
                } else if (currentToken() instanceof T_LeftCurlyBracket) {
                    return parseBlock();
                } else {
                    throw new SyntaxException("Unexpected token: " + currentToken().getClass().getSimpleName() + " at index " + currentIndex);
                }
            }
        };
    }
}

class Main {
    public static void main(String[] args) throws Exception {
        Parser parser = Task3.create();

        List<Token> tokens = List.of(
            new T_LeftCurlyBracket(),
            new T_Integer(42),
            new T_Semicolon(),
            new T_Skip(),
            new T_RightCurlyBracket()
        );

        try {
            Block ast = parser.parse(tokens);
            System.out.println("Parsed AST: " + ast.contents);
        } catch (SyntaxException | Task3Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
