class Task1Exception extends Exception {
    public String msg;
    public Task1Exception(String _msg) {
        msg = _msg;
    }
}

interface Matrix2D {
    public int initialState();
    public int terminalState();
    public int nextState(int currentState, int character);
}

interface Language {
    public Boolean decide(int[] input) throws Task1Exception;
}

class Task1 {
    public static Language create(Matrix2D matrix2D) {
        return new Language() {
            @Override
            public Boolean decide(int[] input) throws Task1Exception {
                int currentState = matrix2D.initialState();
                for (int character : input) {
                    currentState = matrix2D.nextState(currentState, character);
                }
                return currentState == matrix2D.terminalState();
            }
        };
    }
}

class Main {
    public static void main(String[] args) throws Exception {
        // Example FSA definition for testing
        Matrix2D exampleMatrix = new Matrix2D() {
            private final int[][] fsaTable = {
                {0, 1},
                {1, 0}
            };
            @Override public int initialState() { return 0; }
            @Override public int terminalState() { return 1; }
            @Override public int nextState(int currentState, int character) {
                return fsaTable[currentState][character];
            }
        };

        // Create the FSA
        Language language = Task1.create(exampleMatrix);

        // Test the FSA with a valid input
        int[] testInput = {0, 1, 0, 1};
        System.out.println("Test result: " + language.decide(testInput)); // Expected: true

        // Test the FSA with an invalid input
        int[] invalidInput = {0, 0, 0, 1};
        System.out.println("Test result: " + language.decide(invalidInput)); // Expected: false
    }
}
